package com.example.lucasconforti.finalredo;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

public class ProfileActivity extends AppCompatActivity {

   // private ImageView mCover;
   // private ImageView mProPic;
    private TextView mWelcome;
   // private TextView mDescription;
    //private ImageButton mSearchButton;
    private String whosLocation;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);


      //  mCover = (ImageView) findViewById(R.id.cover);
      //  mProPic = (ImageView) findViewById(R.id.proPic);
        mWelcome = (TextView) findViewById(R.id.welcome);
       // mDescription = (TextView) findViewById(R.id.description);
      //  mSearchButton = (ImageButton) findViewById(R.id.searchButton);


        Intent intent = getIntent();
        whosLocation = intent.getExtras().getString("Name");
        setTextView();
    }
    public void setTextView()
    {
        mWelcome = (TextView) findViewById(R.id.welcome);
        mWelcome.setText("Welcome " + whosLocation +"!");

    }

    public void onClick (View v){

        switch (v.getId())
        {
            case R.id.searchButton:

                Intent myIntent = new Intent(ProfileActivity.this, MapsActivity.class);
                myIntent.putExtra("Name", whosLocation);
                Log.d("lucas","login name: " + whosLocation);
                ProfileActivity.this.startActivity(myIntent);
                finish();

        }
    }
}
