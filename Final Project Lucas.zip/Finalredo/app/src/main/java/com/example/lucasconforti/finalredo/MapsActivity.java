package com.example.lucasconforti.finalredo;

import android.graphics.Color;
import android.location.Location;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.Circle;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.content.Intent;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.Toast;


public class MapsActivity extends FragmentActivity implements OnMapReadyCallback,
        GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener, LocationListener {

    private GoogleMap mMap;
    private GoogleApiClient client;
    private LocationRequest locationRequest;
    private Location lastLocation;
    private Marker currentLocationMarker;
    public static final int REQUEST_LOCATION_CODE = 99;
    public CheckBox checkBox;
    public boolean box;
    Circle circle;
    double PROXIMITY_RADIUS = 40233.6;
    double latitude, longitude;
    private LatLng latLng;
    //private String url;


    //private final static int MY_PERMISSION_FINE_LOCATION = 101;
    //private FusedLocationProviderClient mFusedLocationClient;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            checkLocationPermission();

        }

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case REQUEST_LOCATION_CODE:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    //permission is granted
                    if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                        if (client == null) {
                            buildGoogleApiClient();

                        }
                        mMap.setMyLocationEnabled(true);
                    }
                } else //permission denied
                {
                    Toast.makeText(this, "Permission Denied!", Toast.LENGTH_LONG).show();
                }
                return;
        }
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {

        mMap = googleMap;


        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            buildGoogleApiClient();
            mMap.setMyLocationEnabled(true);
        }

    }

    protected synchronized void buildGoogleApiClient() {
        client = new GoogleApiClient.Builder(this).addConnectionCallbacks(this).addOnConnectionFailedListener(this).addApi(LocationServices.API).build();
        client.connect();

    }

    @Override
    public void onLocationChanged(Location location) {
        lastLocation = location;

        if (currentLocationMarker != null) {
            currentLocationMarker.remove();
        }
        Intent intent = getIntent();
        String whosLocation = intent.getExtras().getString("Name");
        Log.d("mylocation", "current location " + whosLocation);

        latLng = new LatLng(location.getLatitude(), location.getLongitude());
        Log.d("Lucas", "LatLng" + latLng);

        MarkerOptions markerOptions = new MarkerOptions();
        markerOptions.position(latLng);
        markerOptions.title(whosLocation);
        markerOptions.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_BLUE));


        currentLocationMarker = mMap.addMarker(markerOptions);


        mMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));
        mMap.animateCamera(CameraUpdateFactory.zoomBy(5));

        if (circle == null) {
            circle = mMap.addCircle(new CircleOptions().center(latLng).radius(40233.6).strokeColor(Color.RED));
        } else {
            circle.remove();
            circle = mMap.addCircle(new CircleOptions().center(latLng).radius(40233.6).strokeColor(Color.RED));
        }

        if (client != null) {
            LocationServices.FusedLocationApi.removeLocationUpdates(client, this);
        }


    }


    public void onClick(View v) {
        //Object dataTransfer[] = new Object[2];
        //GetNearbyPlacesData getNearbyPlacesData = new GetNearbyPlacesData();

        latitude = lastLocation.getLatitude();
        Log.d("Lucas", "Lat" + latitude);

        longitude = lastLocation.getLongitude();
        Log.d("Lucas", "Lng" + longitude);

        switch (v.getId())
        {
            case R.id.searchArea:
                checkBox = (CheckBox) findViewById(R.id.searchArea);
                if (checkBox.isChecked()) {
                    checkBox.setChecked(true);
                    box = true;
                    if (circle == null) {
                        circle = mMap.addCircle(new CircleOptions().center(latLng).radius(16093.4).strokeColor(Color.RED));
                    } else {
                        Log.d("lucas", " circle" + circle);
                        circle.remove();
                        circle = mMap.addCircle(new CircleOptions().center(latLng).radius(16093.4).strokeColor(Color.RED));
                        Log.d("lucas", " circle" + circle);
                    }
                    Log.d("checkedbox", "box" + box);
                }else {
                    checkBox.setChecked(false);
                    box = false;
                    if (circle == null) {

                        circle = mMap.addCircle(new CircleOptions().center(latLng).radius(40233.6).strokeColor(Color.RED));

                    } else {
                        circle.remove();
                        circle = mMap.addCircle(new CircleOptions().center(latLng).radius(40233.6).strokeColor(Color.RED));
                    }
                    Log.d("checkedbox2", "box" + box);
                }
                break;
            case R.id.B_restaurants:
//                String restaurant = "restaurant";
//                url = getUrl(latitude, longitude, restaurant);
//                Log.d("lucas", " latLng" + latitude + " / " + longitude);
//                Log.d("lucas", " url" + url);
//                dataTransfer[0] = mMap;
//                dataTransfer[1] = url;
//                Log.d("lucas", " dataTransfer[0]" + dataTransfer[0]);
//                Log.d("lucas", " dataTransfer[1]" + dataTransfer[1]);
//
//                getNearbyPlacesData.execute(dataTransfer);
                Toast.makeText(MapsActivity.this, "Showing Nearby Restaurants", Toast.LENGTH_LONG).show();

                Intent myIntent = new Intent(MapsActivity.this, RestaurantActivity.class);
                MapsActivity.this.startActivity(myIntent);
                finish();

                break;

        }

    }

    private String getUrl(double latitude, double longitude, String nearbyPlace) {
        StringBuilder googlePlaceUrl = new StringBuilder("https://maps.googleapis.com/maps/api/place/nearbysearch/json?");
        googlePlaceUrl.append("location" + latitude + "," + longitude);
        googlePlaceUrl.append("$radius=" + PROXIMITY_RADIUS);
        googlePlaceUrl.append("&type=" + nearbyPlace);
        googlePlaceUrl.append("&sensor=true");
        googlePlaceUrl.append("&key=" + "AIzaSyDhtpaMRbvmh8R5GJzJ0JN0nfXrK-Mtw_Y");

        return googlePlaceUrl.toString();
    }



    @Override
    public void onConnected(@Nullable Bundle bundle) {
        locationRequest = new LocationRequest();

        locationRequest.setInterval(1000);
        locationRequest.setFastestInterval(1000);
        locationRequest.setPriority(LocationRequest.PRIORITY_BALANCED_POWER_ACCURACY);

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            LocationServices.FusedLocationApi.requestLocationUpdates(client, locationRequest, this);

        }


    }

    public boolean checkLocationPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.ACCESS_FINE_LOCATION)) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION_CODE);
            } else {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION_CODE);
            }
            return false;
        } else
            return true;
    }


    @Override
    public void onConnectionSuspended(int i) {

    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }
}