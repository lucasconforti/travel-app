package com.example.lucasconforti.finalredo;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;


public class DetailActivity extends AppCompatActivity {

    private TextView TitleView;
    private TextView RatingView;
    private TextView CuisineView;
    private TextView LocationView;
    private TextView DetailView;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        TitleView = (TextView) findViewById(R.id.titleView);
        RatingView = (TextView) findViewById(R.id.ratingView);
        CuisineView = (TextView) findViewById(R.id.cuisineView);
        LocationView = (TextView) findViewById(R.id.locationView);
        DetailView = (TextView) findViewById(R.id.detailView);



        setTextView();
    }
    public void setTextView()
    {
        Intent intent = getIntent();
        String name = intent.getExtras().getString("Name");
        String rating = intent.getExtras().getString("Rating");
        String cuisine = intent.getExtras().getString("Cuisine");
        String location = intent.getExtras().getString("Location");
        String detail = intent.getExtras().getString("Detail");


        TitleView = (TextView) findViewById(R.id.titleView);
        TitleView.setText(name);

        RatingView = (TextView) findViewById(R.id.ratingView);
        RatingView.setText(rating);

        CuisineView = (TextView) findViewById(R.id.cuisineView);
        CuisineView.setText(cuisine);

        LocationView = (TextView) findViewById(R.id.locationView);
        LocationView.setText(location);

        DetailView = (TextView) findViewById(R.id.detailView);
        DetailView.setText(detail);


    }
}
