package com.example.lucasconforti.finalredo;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;


import java.util.List;


public class RestaurantActivity extends AppCompatActivity {
    private ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_restaurant);

        this.listView = (ListView) findViewById(R.id.listView);
        final DatabaseAccess databaseAccess = DatabaseAccess.getInstance(this);
        databaseAccess.open();
        List<String> restaurants = databaseAccess.getRestaurants();


        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, restaurants);
        this.listView.setAdapter(adapter);


        //set an onItemClickListener to the ListView
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String Name = adapterView.getItemAtPosition(i).toString();
                Log.d("lucas", "onItemClick: You Clicked on " + Name);
                String Rating ="";
                String Cuisine ="";
                String Location ="";
                String Detail ="";

                Cursor data = databaseAccess.getItemID(Name); //get the id associated with that name
                Log.d("lucas", "cursor data " + data);
                int itemID = -1;
                while(data.moveToNext()){
                    itemID = data.getInt(0);
                    Rating = data.getString(2);
                    Cuisine = data.getString(3);
                    Location = data.getString(4);
                    Detail = data.getString(5);
                }
                if(itemID > -1){
                    Log.d("lucas", "onItemClick: The ID is: " + itemID);
                    Intent editScreenIntent = new Intent(RestaurantActivity.this, DetailActivity.class);
                    editScreenIntent.putExtra("id",itemID);
                    editScreenIntent.putExtra("Name",Name);
                    editScreenIntent.putExtra("Rating",Rating);
                    editScreenIntent.putExtra("Cuisine",Cuisine);
                    editScreenIntent.putExtra("Location",Location);
                    editScreenIntent.putExtra("Detail",Detail);
                    startActivity(editScreenIntent);
                }

            }
        });
    }

    }


