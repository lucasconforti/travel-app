package com.example.lucasconforti.finalredo;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

public class ProfileActivity extends AppCompatActivity {

    private ImageView mCover;
    private ImageView mProPic;
    private TextView mWelcome;
    private TextView mDescription;
    private ImageButton mSearchButton;

    Intent intent = getIntent();
    String whosLocation = intent.getExtras().getString("Name");


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);


        mCover = (ImageView) findViewById(R.id.cover);
        mProPic = (ImageView) findViewById(R.id.proPic);
        mWelcome = (TextView) findViewById(R.id.welcome);
        mDescription = (TextView) findViewById(R.id.description);
        mSearchButton = (ImageButton) findViewById(R.id.searchButton);

        //mWelcome
    }

    public void onClick (View v){

        switch (v.getId())
        {
            case R.id.searchButton:
                String myName = whosLocation;
                Intent myIntent = new Intent(ProfileActivity.this, MapsActivity.class);
                myIntent.putExtra("Name", myName);
                Log.d("lucas","login name: " + myName );
                ProfileActivity.this.startActivity(myIntent);
                finish();

        }
    }
}
