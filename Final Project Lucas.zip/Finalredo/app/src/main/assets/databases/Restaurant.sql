BEGIN TRANSACTION;
CREATE TABLE IF NOT EXISTS `Restaurant` (
	`ID`	INTEGER PRIMARY KEY AUTOINCREMENT,
	`NAME`	TEXT,
	`RATING`	DOUBLE,
	`CUISINE`	TEXT,
	`LOCATION`	TEXT,
	`DESCRIPTION`	TEXT
);
INSERT INTO `Restaurant` (ID,NAME,RATING,CUISINE,LOCATION,DESCRIPTION) VALUES (1,'Zero Otto Nove',4.4,'Neapolitan','2357 Arther Ave','Neapolitan trattoria with tall ceilings');
INSERT INTO `Restaurant` (ID,NAME,RATING,CUISINE,LOCATION,DESCRIPTION) VALUES (2,'Antonio''s Trattoria',4.7,'Italian','2370 Belmon Ave','Brick-oven pizza & classic italian eats');
INSERT INTO `Restaurant` (ID,NAME,RATING,CUISINE,LOCATION,DESCRIPTION) VALUES (3,'Enzo''s',4.5,'Italian','2339 Arther Ave','Warm spot for down-home italian dining');
INSERT INTO `Restaurant` (ID,NAME,RATING,CUISINE,LOCATION,DESCRIPTION) VALUES (4,'Full Moon',4.3,'Pizza','600 E 187th St','Old-school neighborhood slice parlor');
INSERT INTO `Restaurant` (ID,NAME,RATING,CUISINE,LOCATION,DESCRIPTION) VALUES (5,'Emilia''s',4.1,'Italian','2331 Arther Ave','Mainstay for traditional italian dishes');
INSERT INTO `Restaurant` (ID,NAME,RATING,CUISINE,LOCATION,DESCRIPTION) VALUES (6,'Roberto''s',4.3,'Italian','603 Crescent Ave','Italian cuisine in an old-style setting');
INSERT INTO `Restaurant` (ID,NAME,RATING,CUISINE,LOCATION,DESCRIPTION) VALUES (7,'Mario''s',4.3,'Neapolitan Restaurant','2342 Arther Ave','Classic Neapolitan restaurant ');
INSERT INTO `Restaurant` (ID,NAME,RATING,CUISINE,LOCATION,DESCRIPTION) VALUES (8,'Sake II',4.1,'Japanese','690 E 187th St','Storefront sushi bar with japanese mains');
INSERT INTO `Restaurant` (ID,NAME,RATING,CUISINE,LOCATION,DESCRIPTION) VALUES (9,'Checkers',3.1,'Fast food','379 E Fordham Rd','Fast food place for burgers');
INSERT INTO `Restaurant` (ID,NAME,RATING,CUISINE,LOCATION,DESCRIPTION) VALUES (10,'White Castle',4.1,'Fast food','550 E Fordham Rd','Fast food place for mini burgers');
COMMIT;
